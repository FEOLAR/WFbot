try:
    from dotenv import load_dotenv; load_dotenv()
except ImportError:
    pass

import os

# Fallback: load tokens from config.py if env vars not set
try:
    import config as _cfg
    for _k in ("TELEGRAM_BOT_TOKEN", "COC_EMAIL", "COC_PASSWORD"):
        if not os.environ.get(_k):
            os.environ[_k] = getattr(_cfg, _k, "")
except ImportError:
    pass
import asyncio
import logging
import threading
from http.server import HTTPServer, BaseHTTPRequestHandler
from datetime import datetime
from collections import defaultdict
import coc
from telegram import (
    Update, InlineKeyboardButton, InlineKeyboardMarkup,
    ReplyKeyboardMarkup, KeyboardButton, BotCommand, MenuButtonCommands
)
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, filters, ContextTypes
import storage
import stats_storage
import excel_builder
import card_builder
import fmt

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO
)
logger = logging.getLogger(__name__)

IS_PRODUCTION = os.environ.get("REPLIT_DEPLOYMENT") == "1"

TOKEN = os.environ["TELEGRAM_BOT_TOKEN"]
COC_EMAIL = os.environ["COC_EMAIL"]
COC_PASSWORD = os.environ["COC_PASSWORD"]
CLAN_TAG       = "#2R02GGRUJ"
CLAN_WEBSITE   = "https://www.warfilcoc.ru"
TG_GROUP_LINK  = "https://t.me/warfil_clan"   # ← замени на реальную ссылку беседы
WAR_NOTIFY_USERNAME = "feolar"                 # username получателя авто-рассылки войны

ROLE_ORDER = {
    "leader": 0,
    "coLeader": 1,
    "admin": 2,
    "member": 3,
}

coc_client = coc.Client()

# Active auto-update tasks: chat_id -> asyncio.Task
_kv_tasks: dict[int, asyncio.Task] = {}

CLAN_TAG_ENCODED = CLAN_TAG.replace("#", "%23")
KV_BUTTONS = InlineKeyboardMarkup([
    [
        InlineKeyboardButton("🌐 Сайт клана", url=CLAN_WEBSITE),
        InlineKeyboardButton("⚔️ Открыть игру", url=f"https://link.clashofclans.com/en?action=OpenClanProfile&tag={CLAN_TAG_ENCODED}"),
    ]
])


async def build_war_message() -> tuple[str, bool]:
    """Fetch current war and return (text, should_keep_updating)."""
    war = await coc_client.get_current_war(CLAN_TAG)

    if war is None or war.state == "notInWar":
        return "🏳️ Клан сейчас не в клановой войне.", False

    if war.state == "preparation":
        start = war.start_time.time.strftime("%d.%m в %H:%M") if war.start_time else "скоро"
        return f"⚙️ Идёт подготовка к войне. Бой начнётся {start} (UTC).", False

    attacks_per_member = war.attacks_per_member or 2
    pending = []
    for member in war.clan.members:
        used = len(member.attacks) if member.attacks else 0
        remaining = attacks_per_member - used
        if remaining > 0:
            pending.append((member, used, remaining))
    pending.sort(key=lambda x: x[1])

    state_label = "⚔️ ВОЙНА ИДЁТ" if war.state == "inWar" else "🏁 ВОЙНА ЗАВЕРШЕНА"
    our_stars = war.clan.stars
    their_stars = war.opponent.stars

    time_str = ""
    if war.state == "inWar" and war.end_time:
        now = datetime.utcnow()
        diff = war.end_time.time - now
        total_sec = max(int(diff.total_seconds()), 0)
        h, m = divmod(total_sec // 60, 60)
        time_str = f"\n⏱ До конца: <b>{h}ч {m}мин</b>"

    lines = [
        f"<b>{state_label}</b>",
        fmt.DIV,
        f"🏰 <b>{war.clan.name}</b>  ⚔️  <b>{war.opponent.name}</b>",
        f"👥 {war.team_size}v{war.team_size}  ·  ⭐ {our_stars} vs {their_stars}" + time_str,
    ]

    # Attack progress bar
    total_attacks = war.team_size * attacks_per_member
    used_attacks  = total_attacks - sum(r for _, _, r in pending)
    lines.append(f"\n⚔️ Атаки: {fmt.attacks_bar(used_attacks, total_attacks)}  <i>{used_attacks}/{total_attacks}</i>")

    if not pending:
        lines.append(f"\n{fmt.ok('<b>Все использовали атаки!</b>')}")
    else:
        zero_used = [(mb, r) for mb, u, r in pending if u == 0]
        one_used  = [(mb, r) for mb, u, r in pending if u == 1]
        tg_map = storage.get_tg_username_map()

        if zero_used:
            lines.append(f"\n🔴 <b>Нет атак ({len(zero_used)}):</b>")
            for member, _ in zero_used:
                tg = tg_map.get(member.name.lower())
                lines.append(fmt.member_line(member.name, tg=tg))

        if one_used:
            lines.append(f"\n🟡 <b>Осталась 1 ({len(one_used)}):</b>")
            for member, _ in one_used:
                tg = tg_map.get(member.name.lower())
                lines.append(fmt.member_line(member.name, tg=tg))

    lines.append(fmt.footer())
    keep_updating = war.state == "inWar"
    return "\n".join(lines), keep_updating


def format_last_seen(last_seen_str: str | None) -> str:
    if not last_seen_str:
        return ""
    try:
        dt = datetime.fromisoformat(last_seen_str)
        now = datetime.now()
        diff = now - dt
        minutes = int(diff.total_seconds() // 60)
        if minutes < 1:
            return " • 🟢 только что"
        elif minutes < 60:
            return f" • 🕐 {minutes} мин. назад"
        elif minutes < 1440:
            hours = minutes // 60
            return f" • 🕐 {hours} ч. назад"
        else:
            days = minutes // 1440
            return f" • 💤 {days} дн. назад"
    except Exception:
        return ""


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    name = user.first_name or "боец"

    # Save chat_id for the war broadcast target when they DM the bot
    if (update.effective_chat.type == "private"
            and user.username
            and user.username.lower() == WAR_NOTIFY_USERNAME.lower()):
        storage.save_notify_chat(update.effective_chat.id)
        logger.info(f"Saved war notify chat_id: {update.effective_chat.id}")

    # Fetch live clan data for welcome card
    try:
        clan = await coc_client.get_clan(CLAN_TAG)
        stats_block = (
            f"\n{fmt.DIVs}\n\n"
            f"{fmt.stat_line('Уровень клана', str(clan.level))}\n"
            f"{fmt.stat_line('Состав', f'{clan.member_count} / 50')}\n"
            f"{fmt.stat_line('Побед в войнах', str(clan.war_wins))}\n"
        )
    except Exception:
        stats_block = ""

    text = (
        f"👋 Привет, <b>{name}</b>!\n"
        f"{fmt.DIV}\n"
        f"{fmt.clan_header()}\n\n"
        "<i>Warfil — это не просто клан.\n"
        "Это боевое братство, где стратегия\n"
        "и честь важнее, чем числа на экране.\n"
        "Мы атакуем вместе. Побеждаем достойно.</i>"
        f"{stats_block}"
        f"\n{fmt.DIV}\n"
        "Все команды — в меню ниже 👇\n"
        f"{fmt.footer()}"
    )

    inline_kb = InlineKeyboardMarkup([
        [
            InlineKeyboardButton("🌐 Сайт клана", url=CLAN_WEBSITE),
            InlineKeyboardButton("💬 Беседа клана", url=TG_GROUP_LINK),
        ]
    ])

    await update.message.reply_text(text, parse_mode="HTML", reply_markup=inline_kb)


async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = (
        f"📖 <b>Команды бота Warfil</b>\n"
        f"{fmt.DIV}\n\n"
        f"📋 /team\n"
        f"   Список участников клана\n\n"
        f"⚔️ /kv\n"
        f"   Атаки в клановой войне\n\n"
        f"🏆 /cwl\n"
        f"   Лига войн клана\n\n"
        f"📊 /statistic\n"
        f"   Статистика клана (Excel)\n\n"
        f"🎨 /card\n"
        f"   Карточка клана\n\n"
        f"🔗 /register &lt;ник&gt;\n"
        f"   Привязать аккаунт CoC\n"
        f"   <i>Пример: /register WarriorKing</i>\n\n"
        f"{fmt.DIV}\n"
        f"🛡 <b>Для администраторов</b>\n\n"
        f"▸ /link @tg НикВCoC\n"
        f"▸ /unlink НикВCoC\n"
        f"▸ /links — все привязки\n"
        f"{fmt.footer()}"
    )
    await update.message.reply_text(text, parse_mode="HTML")


async def register_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args:
        await update.message.reply_text(
            "Укажи своё имя в игре.\n"
            "Пример: /register WarriorKing"
        )
        return

    coc_name = " ".join(context.args)
    user_id = update.effective_user.id
    tg_username = update.effective_user.username
    storage.register_player(user_id, coc_name, tg_username)
    storage.update_last_seen(user_id)
    linked = f" · @{tg_username}" if tg_username else ""
    await update.message.reply_text(
        f"🔗 <b>Аккаунт привязан</b>\n"
        f"{fmt.DIV}\n\n"
        f"▸ Ник в игре: <b>{coc_name}</b>{linked}\n\n"
        f"Теперь ты виден в /team со своим Telegram.",
        parse_mode="HTML"
    )


async def online_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    coc_name = storage.update_last_seen(user_id)
    if coc_name:
        await update.message.reply_text(
            f"✅ <b>{coc_name}</b>, твоя активность отмечена!",
            parse_mode="HTML"
        )
    else:
        await update.message.reply_text(
            "Ты ещё не зарегистрирован.\n"
            "Используй /register <имя в игре> чтобы привязать аккаунт."
        )


async def team_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    msg = await update.message.reply_text("⏳ Загружаю список клана...")
    try:
        clan = await coc_client.get_clan(CLAN_TAG)
        members_sorted = sorted(
            clan.members,
            key=lambda m: (ROLE_ORDER.get(m.role.value, 9), m.name.lower())
        )

        # Group members by role (store full member objects)
        groups: dict[str, list] = defaultdict(list)
        for member in members_sorted:
            groups[member.role.value].append(member)

        ROLE_HEADERS = {
            "leader":   "👑 <b>Лидер</b>",
            "coLeader": "🔱 <b>Соруководители</b>",
            "admin":    "🌿 <b>Старейшины</b>",
            "member":   "🔹 <b>Участники</b>",
        }

        tg_map = storage.get_tg_username_map()

        lines = [
            f"🏰 <b>{clan.name}</b>  ·  👥 {clan.member_count}/50",
            fmt.DIV,
        ]

        for role_key in ["leader", "coLeader", "admin", "member"]:
            members = groups.get(role_key)
            if not members:
                continue
            lines.append("")
            count_str = f"  <i>({len(members)})</i>" if role_key != "leader" else ""
            lines.append(ROLE_HEADERS[role_key] + count_str)
            for m in members:
                tg = tg_map.get(m.name.lower())
                lines.append(fmt.member_line(m.name, m.town_hall, tg))

        lines.append(f"\n{fmt.footer()}")

        await msg.edit_text("\n".join(lines), parse_mode="HTML")

    except coc.NotFound:
        await msg.edit_text("❌ Клан не найден. Проверь тег клана.")
    except Exception as e:
        logger.error(f"Ошибка при получении данных клана: {e}")
        await msg.edit_text("❌ Не удалось загрузить данные. Попробуй позже.")


async def _is_admin(update: Update) -> bool:
    """True if the sender is a group admin/creator, or if used in a private chat."""
    chat = update.effective_chat
    if chat.type == "private":
        return True
    member = await chat.get_member(update.effective_user.id)
    return member.status in ("administrator", "creator")


async def link_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Usage: /link @tg_username Ник в CoC"""
    if not await _is_admin(update):
        await update.message.reply_text("❌ Только администраторы могут использовать эту команду.")
        return

    if len(context.args) < 2:
        await update.message.reply_text(
            "Использование: /link @telegram НикВCoC\n"
            "Примеры:\n"
            "  /link @feolar Fanon\n"
            "  /link @feolar fil\n\n"
            "Один @telegram можно привязать к нескольким никам."
        )
        return

    tg_username = context.args[0].lstrip("@")
    coc_name = " ".join(context.args[1:])

    storage.link_player(coc_name, tg_username)
    await update.message.reply_text(
        f"✅ <b>{coc_name}</b> привязан к @{tg_username}",
        parse_mode="HTML"
    )


async def unlink_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Usage: /unlink Ник в CoC"""
    if not await _is_admin(update):
        await update.message.reply_text("❌ Только администраторы могут использовать эту команду.")
        return

    if not context.args:
        await update.message.reply_text("Использование: /unlink НикВCoC\nПример: /unlink Fanon")
        return

    coc_name = " ".join(context.args)
    removed = storage.unlink_player(coc_name)
    if removed:
        await update.message.reply_text(f"✅ Привязка для <b>{coc_name}</b> удалена.", parse_mode="HTML")
    else:
        await update.message.reply_text(f"⚠️ Привязка для <b>{coc_name}</b> не найдена.", parse_mode="HTML")


async def links_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show all current links (admin only)."""
    if not await _is_admin(update):
        await update.message.reply_text("❌ Только администраторы могут использовать эту команду.")
        return

    all_links = storage.get_all_links()
    if not all_links:
        await update.message.reply_text("Привязок пока нет. Используй /link @telegram НикВCoC")
        return

    lines = ["📋 <b>Текущие привязки:</b>", ""]
    for coc_name, tg_user in sorted(all_links.items(), key=lambda x: x[1]):
        lines.append(f"  {coc_name} → @{tg_user}")
    await update.message.reply_text("\n".join(lines), parse_mode="HTML")


async def kv_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id

    # Cancel any existing auto-update task for this chat
    existing = _kv_tasks.get(chat_id)
    if existing and not existing.done():
        existing.cancel()

    msg = await update.message.reply_text("⏳ Загружаю данные войны...")

    try:
        text, keep_updating = await build_war_message()
        await msg.edit_text(text, parse_mode="HTML", reply_markup=KV_BUTTONS)
    except coc.PrivateWarLog:
        await msg.edit_text("🔒 Журнал войны клана закрыт.")
        return
    except coc.NotFound:
        await msg.edit_text("❌ Клан не найден.")
        return
    except Exception as e:
        logger.error(f"Ошибка /kv: {e}")
        await msg.edit_text("❌ Не удалось загрузить данные войны. Попробуй позже.")
        return

    if not keep_updating:
        return

    async def auto_update():
        while True:
            await asyncio.sleep(5)
            try:
                new_text, still_going = await build_war_message()
                try:
                    await msg.edit_text(new_text, parse_mode="HTML", reply_markup=KV_BUTTONS)
                except Exception:
                    pass  # Message not modified or deleted — skip silently
                if not still_going:
                    break
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.warning(f"Ошибка авто-обновления /kv: {e}")
                break

    task = asyncio.create_task(auto_update())
    _kv_tasks[chat_id] = task


async def echo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text
    # Route reply-keyboard button presses to the right commands
    if text == "📋 Список клана":
        await team_command(update, context)
    elif text == "❓ Помощь":
        await help_command(update, context)
    elif text == "🔗 Привязать аккаунт":
        await update.message.reply_text(
            "Чтобы привязать свой аккаунт, напиши:\n"
            "/register &lt;твой ник в CoC&gt;\n\n"
            "<i>Пример: /register WarriorKing</i>",
            parse_mode="HTML"
        )
    else:
        pass  # ignore other text messages


async def send_war_start(bot, chat_id: int, war):
    opponent = war.opponent.name if war.opponent else "противника"
    text = (
        f"⚔️ <b>ВОЙНА НАЧАЛАСЬ!</b>\n"
        f"{fmt.DIV}\n\n"
        f"🏰 <b>Warfil</b>  vs  <b>{opponent}</b>\n"
        f"👥 {war.team_size} на {war.team_size}\n\n"
        f"{fmt.DIVs}\n"
        f"💥 Боевой день открыт!\n"
        f"▸ Атакуйте с умом\n"
        f"▸ Сражайтесь с честью\n\n"
        f"<b>Удачи бойцам Warfil! 💪</b>"
    )
    await bot.send_message(chat_id=chat_id, text=text, parse_mode="HTML", reply_markup=KV_BUTTONS)


async def send_war_end(bot, chat_id: int, war):
    attacks_per_member = war.attacks_per_member or 2
    tg_map = storage.get_tg_username_map()

    attacked = []
    missed = []
    for member in war.clan.members:
        used = len(member.attacks) if member.attacks else 0
        if used >= attacks_per_member:
            attacked.append(member)
        else:
            missed.append((member, used))

    our_stars = war.clan.stars
    their_stars = war.opponent.stars
    if our_stars > their_stars:
        result_line = "🏆 <b>Победа!</b>"
    elif our_stars < their_stars:
        result_line = "😔 <b>Поражение.</b>"
    else:
        result_line = "🤝 <b>Ничья.</b>"

    lines = [
        f"🏁 <b>ВОЙНА ЗАВЕРШЕНА</b>",
        fmt.DIV,
        f"🏰 <b>Warfil</b>  vs  <b>{war.opponent.name}</b>",
        f"⭐ {our_stars}  vs  {their_stars}  ·  {result_line}",
    ]

    if attacked:
        lines.append(f"\n✅ <b>Атаковали ({len(attacked)}):</b>")
        for member in attacked:
            tg = tg_map.get(member.name.lower())
            lines.append(fmt.member_line(member.name, tg=tg))
        lines.append("\n🔥 <i>Молодцы! Вы — гордость клана!</i>")

    if missed:
        lines.append(f"\n❌ <b>Не атаковали ({len(missed)}):</b>")
        for member, used in missed:
            tg = tg_map.get(member.name.lower())
            used_str = f" ({used}/{attacks_per_member})" if used > 0 else ""
            lines.append(fmt.member_line(f"{member.name}{used_str}", tg=tg))
        lines.append(f"\n{fmt.warn('<b>Игроки без атак — кандидаты на кик!</b>')}")

    # Save stats for Excel
    result_str = "win" if our_stars > their_stars else ("lose" if our_stars < their_stars else "tie")
    end_str = war.end_time.time.strftime("%Y-%m-%dT%H:%M:%S") if war.end_time else ""
    member_stats = []
    for member in war.clan.members:
        used = len(member.attacks) if member.attacks else 0
        member_stats.append({"name": member.name, "attacks_used": used, "attacks_max": attacks_per_member})
    stats_storage.save_war_result(
        end_time=end_str, opponent=war.opponent.name,
        result=result_str, our_stars=our_stars, their_stars=their_stars,
        team_size=war.team_size, attacks_per_member=attacks_per_member,
        members=member_stats,
    )

    await bot.send_message(chat_id=chat_id, text="\n".join(lines), parse_mode="HTML", reply_markup=KV_BUTTONS)


async def _try_save_war_ended(war):
    """If war is warEnded and not yet saved locally, save it now."""
    if not war or war.state != "warEnded":
        return
    try:
        clan_tag_clean = CLAN_TAG.lstrip("#").upper()
        our = war.clan if war.clan.tag.lstrip("#").upper() == clan_tag_clean else war.opponent
        opp = war.opponent if our is war.clan else war.clan
        end_iso = war.end_time.time.isoformat() if war.end_time else ""
        if not end_iso:
            return
        existing = stats_storage.get_war_history()
        if any(w.get("end_time", "")[:16] == end_iso[:16] for w in existing):
            return  # already saved
        # Determine result
        if our.stars > opp.stars:
            result = "win"
        elif our.stars < opp.stars:
            result = "lose"
        elif (our.destruction or 0) > (opp.destruction or 0):
            result = "win"
        elif (our.destruction or 0) < (opp.destruction or 0):
            result = "lose"
        else:
            result = "tie"
        members = []
        for m in (our.members or []):
            members.append({
                "name": m.name,
                "th": getattr(m, "town_hall", 0),
                "attacks_used": len(m.attacks) if m.attacks else 0,
                "attacks_max": war.attacks_per_member,
            })
        stats_storage.save_war_result(
            end_time=end_iso,
            opponent=opp.name,
            result=result,
            our_stars=our.stars,
            their_stars=opp.stars,
            team_size=war.team_size,
            attacks_per_member=war.attacks_per_member,
            members=members,
        )
        logger.info(f"Auto-saved warEnded: vs {opp.name} at {end_iso[:10]}")
    except Exception as e:
        logger.warning(f"_try_save_war_ended: {e}")


async def war_state_monitor(bot):
    """Poll war state every 60 s; send messages on transitions."""
    previous_state = storage.get_war_state()  # restore across restarts

    # On startup: if war is already ended, save data immediately (bot may have missed the transition)
    try:
        startup_war = await coc_client.get_current_war(CLAN_TAG)
        if startup_war and startup_war.state == "warEnded":
            await _try_save_war_ended(startup_war)
    except Exception:
        pass

    while True:
        await asyncio.sleep(60)
        try:
            chat_ids = storage.get_notify_chats()
            if not chat_ids:
                continue

            war = await coc_client.get_current_war(CLAN_TAG)
            current_state = war.state.value if war and war.state else "notInWar"

            if previous_state is not None and previous_state != current_state:
                for chat_id in chat_ids:
                    try:
                        if previous_state == "preparation" and current_state == "inWar":
                            await send_war_start(bot, chat_id, war)
                        elif previous_state == "inWar" and current_state == "warEnded":
                            await send_war_end(bot, chat_id, war)
                    except Exception as e:
                        logger.warning(f"war_state_watcher: ошибка отправки в {chat_id}: {e}")

            # Also auto-save if we see warEnded state (belt-and-suspenders)
            if current_state == "warEnded":
                await _try_save_war_ended(war)

            if current_state != previous_state:
                storage.save_war_state(current_state)
                previous_state = current_state

        except asyncio.CancelledError:
            break
        except Exception as e:
            logger.warning(f"war_state_monitor: {e}")


async def war_auto_broadcast(bot):
    """Send a new war status message to WAR_NOTIFY_CHAT every 7200 seconds while war is active."""
    while True:
        await asyncio.sleep(7200)  # 2 часа — ждём СНАЧАЛА, чтобы не слать при каждом перезапуске
        try:
            chat_ids = storage.get_notify_chats()
            if not chat_ids:
                logger.debug("war_auto_broadcast: chat_ids not set yet, waiting...")
                continue
            text, keep_going = await build_war_message()
            if keep_going:
                for chat_id in chat_ids:
                    try:
                        await bot.send_message(
                            chat_id=chat_id,
                            text=text,
                            parse_mode="HTML",
                            reply_markup=KV_BUTTONS,
                        )
                    except Exception as e:
                        logger.warning(f"war_auto_broadcast: ошибка отправки в {chat_id}: {e}")
        except asyncio.CancelledError:
            break
        except Exception as e:
            logger.warning(f"war_auto_broadcast: {e}")


def _is_feolar(update: Update) -> bool:
    user = update.effective_user
    return user is not None and (user.username or "").lower() == WAR_NOTIFY_USERNAME.lower()


async def teststart_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not _is_feolar(update):
        await update.message.reply_text("❌ Нет доступа.")
        return
    try:
        war = await coc_client.get_current_war(CLAN_TAG)
        if war is None or war.state == "notInWar":
            await update.message.reply_text("⚠️ Клан не в войне — нет данных для теста.")
            return
        await send_war_start(context.bot, update.effective_chat.id, war)
    except Exception as e:
        await update.message.reply_text(f"❌ Ошибка: {e}")


async def testend_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not _is_feolar(update):
        await update.message.reply_text("❌ Нет доступа.")
        return
    try:
        war = await coc_client.get_current_war(CLAN_TAG)
        if war is None or war.state == "notInWar":
            await update.message.reply_text("⚠️ Клан не в войне — нет данных для теста.")
            return
        await send_war_end(context.bot, update.effective_chat.id, war)
    except Exception as e:
        await update.message.reply_text(f"❌ Ошибка: {e}")


async def statistic_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    msg = await update.message.reply_text("⏳ Собираю статистику, подождите...")
    try:
        clan_tag_clean = CLAN_TAG.lstrip("#").upper()

        # ── Helper: extract player data from a ClanWar object ──────────────────
        def _war_members(war_obj):
            our = war_obj.clan
            if our.tag.lstrip("#").upper() != clan_tag_clean:
                our = war_obj.opponent
            members = []
            for m in (our.members or []):
                members.append({
                    "name": m.name,
                    "th": getattr(m, "town_hall", 0),
                    "attacks_used": len(m.attacks) if m.attacks else 0,
                    "attacks_max": war_obj.attacks_per_member,
                })
            return members

        def _war_result(war_obj):
            our = war_obj.clan
            opp = war_obj.opponent
            if our.tag.lstrip("#").upper() != clan_tag_clean:
                our, opp = opp, our
            if war_obj.state != "warEnded":
                return "—"
            if our.stars > opp.stars:
                return "win"
            elif our.stars < opp.stars:
                return "lose"
            elif (our.destruction or 0) > (opp.destruction or 0):
                return "win"
            elif (our.destruction or 0) < (opp.destruction or 0):
                return "lose"
            return "tie"

        # ── Fetch clan member list (always available, used as player row fallback) ──
        clan_members: list[dict] = []
        try:
            clan = await coc_client.get_clan(CLAN_TAG)
            for m in (clan.members or []):
                clan_members.append({"name": m.name, "th": getattr(m, "town_hall", 0)})
        except Exception as e:
            logger.warning(f"Clan members: {e}")


        # ── 1. КВ: war log (5 regular wars) + live player data overlay ─────────
        # Index from saved history: (end_time[:16], opponent_name) → members
        saved_wars = stats_storage.get_war_history()
        player_by_time: dict[str, list] = {}
        player_by_opp: dict[str, list] = {}
        for sw in saved_wars:
            key_t = sw.get("end_time", "")[:16]
            key_o = sw.get("opponent", "").strip().lower()
            if sw.get("members"):
                if key_t:
                    player_by_time[key_t] = sw["members"]
                if key_o:
                    player_by_opp[key_o] = sw["members"]

        # Fetch current war for live player data and auto-save if warEnded
        try:
            cw = await coc_client.get_current_war(CLAN_TAG)
            if cw and cw.state in ("inWar", "warEnded"):
                cw_end = cw.end_time.time.isoformat() if cw.end_time else ""
                members_live = _war_members(cw)
                if cw_end:
                    player_by_time[cw_end[:16]] = members_live
                opp_name = (cw.opponent.name if cw.opponent else "").strip().lower()
                if opp_name:
                    player_by_opp[opp_name] = members_live
                # Auto-save warEnded war if not already saved
                if cw.state == "warEnded":
                    await _try_save_war_ended(cw)
        except Exception as e:
            logger.warning(f"Текущая КВ: {e}")

        # Fetch war log for the last 5 regular wars (summaries)
        war_history: list[dict] = []
        try:
            async for entry in await coc_client.get_war_log(CLAN_TAG, limit=10):
                # Skip CWL entries (opponent is None)
                if entry.opponent is None:
                    continue
                end_iso = entry.end_time.time.isoformat() if entry.end_time else ""
                result_str = "—"
                try:
                    result_str = entry.result.value if hasattr(entry.result, "value") else str(entry.result).lower()
                except Exception:
                    pass
                opp_name = (entry.opponent.name or "").strip()
                # Match player data by time first, then by opponent name
                key_t = end_iso[:16]
                key_o = opp_name.lower()
                members = (player_by_time.get(key_t)
                           or player_by_opp.get(key_o)
                           or [])
                war_history.append({
                    "end_time": end_iso,
                    "opponent": opp_name or "—",
                    "result": result_str,
                    "our_stars": entry.clan.stars if entry.clan else 0,
                    "their_stars": entry.opponent.stars if entry.opponent else 0,
                    "team_size": entry.team_size or 0,
                    "attacks_per_member": entry.attacks_per_member or 2,
                    "members": members,
                })
                if len(war_history) >= 5:
                    break
        except Exception as e:
            logger.warning(f"War log error: {e}")
            war_history = saved_wars[:5]

        if not war_history:
            war_history = saved_wars[:5]

        # ── 2. ЛВК: current season (live API) + previous seasons (saved) ───────
        cwl_seasons: list[dict] = []

        # Live current season
        live_season = None
        try:
            group = await coc_client.get_league_group(CLAN_TAG)
            live_season = group.season
            live_rounds = []
            round_num = 0
            async for war in group.get_wars_for_clan(CLAN_TAG):
                round_num += 1
                if war.state == "notInWar":
                    continue
                our_side = war.clan if war.clan.tag.lstrip("#").upper() == clan_tag_clean else war.opponent
                opp_side = war.opponent if our_side is war.clan else war.clan
                members = [{"name": m.name, "attacked": bool(m.attacks)}
                           for m in (our_side.members or [])]
                live_rounds.append({
                    "round": round_num,
                    "opponent": opp_side.name,
                    "our_stars": our_side.stars,
                    "their_stars": opp_side.stars,
                    "state": war.state.value if hasattr(war.state, "value") else str(war.state),
                    "members": members,
                })
            if live_rounds:
                cwl_seasons.append({
                    "season": live_season,
                    "rounds": sorted(live_rounds, key=lambda r: r["round"]),
                })
        except coc.NotFound:
            pass
        except Exception as e:
            logger.warning(f"ЛВК live error: {e}")

        # Saved seasons (include any season != current live season)
        for saved_s in stats_storage.get_cwl_seasons():
            if saved_s.get("season") != live_season and saved_s.get("rounds"):
                cwl_seasons.append(saved_s)

        # If nothing live, try all saved
        if not cwl_seasons:
            cwl_seasons = stats_storage.get_cwl_seasons()

        # ── 3. Рейды столицы: только последний рейд ────────────────────────────
        raids = []
        try:
            raid_log = await coc_client.get_raid_log(CLAN_TAG, limit=1)
            async for entry in raid_log:
                raids.append(entry)
        except Exception as e:
            logger.warning(f"Рейды: {e}")

        buf = excel_builder.build_excel(
            war_history, cwl_seasons, raids,
            clan_members=clan_members,
        )
        n_cwl_rounds = sum(len(s.get("rounds", [])) for s in cwl_seasons)
        await update.message.reply_document(
            document=buf,
            filename="warfil_statistics.xlsx",
            caption=(
                f"📊 <b>Статистика Warfil</b>\n"
                f"{fmt.DIV}\n\n"
                f"⚔️ КВ — {len(war_history)} войн\n"
                f"🏆 ЛВК — {len(cwl_seasons)} сезон(а), {n_cwl_rounds} раундов\n"
                f"🏛 Рейды столицы — последний рейд\n"
                f"{fmt.footer()}"
            ),
            parse_mode="HTML",
        )
        await msg.delete()
    except Exception as e:
        logger.error(f"Ошибка /statistic: {e}", exc_info=True)
        await msg.edit_text("❌ Не удалось сгенерировать файл. Попробуй позже.")


async def get_cwl_clan_war(war_round=coc.WarRound.current_war):
    """Return (war, group, round_num) for our clan in the requested CWL round, or (None, group, 0)."""
    try:
        group = await coc_client.get_league_group(CLAN_TAG)
    except (coc.NotFound, Exception):
        return None, None, 0

    round_num = len(group.rounds)
    try:
        async for war in group.get_wars(war_round):
            clan_tag_clean = CLAN_TAG.lstrip("#").upper()
            if (war.clan.tag.lstrip("#").upper() == clan_tag_clean
                    or war.opponent.tag.lstrip("#").upper() == clan_tag_clean):
                return war, group, round_num
    except Exception:
        pass
    return None, group, round_num


async def build_cwl_message() -> tuple[str, bool]:
    """Build CWL status message. Returns (text, keep_updating)."""
    war, group, round_num = await get_cwl_clan_war()

    if group is None:
        return "🏳️ Клан не участвует в Лиге войн клана.", False

    if war is None or group.state == "preparation":
        return f"⚙️ ЛВК — идёт подготовка. Раундов сыграно: {round_num}.", False

    if group.state == "ended":
        return "🏁 Сезон Лиги войн клана завершён.", False

    clan_tag_clean = CLAN_TAG.lstrip("#").upper()
    our_side = war.clan if war.clan.tag.lstrip("#").upper() == clan_tag_clean else war.opponent
    opp_side = war.opponent if our_side is war.clan else war.clan

    attacks_per_member = 1
    pending = []
    for member in our_side.members:
        used = len(member.attacks) if member.attacks else 0
        if used < attacks_per_member:
            pending.append(member)

    state_label = "⚔️ ЛВК идёт" if group.state == "inWar" else "🏁 ЛВК раунд завершён"
    our_stars = our_side.stars
    their_stars = opp_side.stars

    time_str = ""
    if group.state == "inWar" and war.end_time:
        now = datetime.utcnow()
        diff = war.end_time.time - now
        total_sec = max(int(diff.total_seconds()), 0)
        h, m = divmod(total_sec // 60, 60)
        time_str = f"\n⏱ До конца раунда: <b>{h}ч {m}мин</b>"

    lines = [
        f"<b>{state_label} — Раунд {round_num}</b>",
        fmt.DIV,
        f"🏰 <b>{our_side.name}</b>  ⚔️  <b>{opp_side.name}</b>",
        f"⭐ {our_stars}  vs  {their_stars}" + time_str,
    ]

    if not pending:
        lines.append(f"\n{fmt.ok('<b>Все атаковали в раунде!</b>')}")
    else:
        lines.append(f"\n🔴 <b>Не атаковали — {len(pending)} чел.</b>")
        tg_map = storage.get_tg_username_map()
        for member in pending:
            tg = tg_map.get(member.name.lower())
            lines.append(fmt.member_line(member.name, tg=tg))

    lines.append(fmt.footer())
    keep_updating = group.state == "inWar"
    return "\n".join(lines), keep_updating


async def send_cwl_start(bot, chat_id: int, war, group, round_num: int):
    clan_tag_clean = CLAN_TAG.lstrip("#").upper()
    our_side = war.clan if war.clan.tag.lstrip("#").upper() == clan_tag_clean else war.opponent
    opp_side = war.opponent if our_side is war.clan else war.clan
    opponent_name = opp_side.name if opp_side else "противника"

    text = (
        f"🏆 <b>ЛВК — РАУНД {round_num} НАЧАЛСЯ!</b>\n"
        f"{fmt.DIV}\n\n"
        f"🏰 <b>Warfil</b>  vs  <b>{opponent_name}</b>\n\n"
        f"{fmt.DIVs}\n"
        f"💥 Помните: в ЛВК только <b>1 атака</b>!\n"
        f"▸ Выбирайте цели тщательно\n"
        f"▸ Атакуйте с умом\n\n"
        f"<b>Удачи бойцам Warfil! 💪</b>"
    )
    await bot.send_message(chat_id=chat_id, text=text, parse_mode="HTML", reply_markup=KV_BUTTONS)


async def send_cwl_end(bot, chat_id: int, war, round_num: int):
    clan_tag_clean = CLAN_TAG.lstrip("#").upper()
    our_side = war.clan if war.clan.tag.lstrip("#").upper() == clan_tag_clean else war.opponent
    opp_side = war.opponent if our_side is war.clan else war.clan
    tg_map = storage.get_tg_username_map()

    attacked = []
    missed = []
    for member in our_side.members:
        used = len(member.attacks) if member.attacks else 0
        if used >= 1:
            attacked.append(member)
        else:
            missed.append(member)

    our_stars = our_side.stars
    their_stars = opp_side.stars
    if our_stars > their_stars:
        result_line = "🏆 <b>Победа в раунде!</b>"
    elif our_stars < their_stars:
        result_line = "😔 <b>Поражение в раунде.</b>"
    else:
        result_line = "🤝 <b>Ничья в раунде.</b>"

    lines = [
        f"🏁 <b>ЛВК — РАУНД {round_num} ЗАВЕРШЁН</b>",
        fmt.DIV,
        f"🏰 <b>Warfil</b>  vs  <b>{opp_side.name}</b>",
        f"⭐ {our_stars}  vs  {their_stars}  ·  {result_line}",
    ]

    if attacked:
        lines.append(f"\n✅ <b>Атаковали ({len(attacked)}):</b>")
        for member in attacked:
            tg = tg_map.get(member.name.lower())
            lines.append(fmt.member_line(member.name, tg=tg))
        lines.append("\n🔥 <i>Молодцы! Продолжайте в том же духе!</i>")

    if missed:
        lines.append(f"\n❌ <b>Не атаковали ({len(missed)}):</b>")
        for member in missed:
            tg = tg_map.get(member.name.lower())
            lines.append(fmt.member_line(member.name, tg=tg))
        lines.append(f"\n{fmt.warn('<b>Игроки без атак — кандидаты на кик!</b>')}")

    # Save CWL round stats for Excel
    # Determine current season from CWL group if possible (use YYYY-MM format)
    try:
        group = await coc_client.get_league_group(CLAN_TAG)
        season = group.season or "unknown"
    except Exception:
        season = "unknown"
    member_stats = []
    for m in attacked:
        member_stats.append({"name": m.name, "attacked": True})
    for m in missed:
        member_stats.append({"name": m.name, "attacked": False})
    stats_storage.save_cwl_round(
        season=season, round_num=round_num,
        opponent=opp_side.name,
        our_stars=our_stars, their_stars=their_stars,
        members=member_stats,
    )

    await bot.send_message(chat_id=chat_id, text="\n".join(lines), parse_mode="HTML", reply_markup=KV_BUTTONS)


async def cwl_state_monitor(bot):
    """Poll CWL state every 60s; send messages on round start/end transitions."""
    saved = storage.get_cwl_state()
    prev_state = saved.get("state") if saved else None
    prev_round = saved.get("round_count", 0) if saved else 0

    while True:
        await asyncio.sleep(60)
        try:
            chat_ids = storage.get_notify_chats()
            if not chat_ids:
                continue

            group = await coc_client.get_league_group(CLAN_TAG)
            current_state = group.state or "notInWar"
            current_round = len(group.rounds)

            # New round started (inWar AND round count increased)
            if current_state == "inWar" and (prev_state != "inWar" or current_round != prev_round):
                war, _, _ = await get_cwl_clan_war()
                if war:
                    for chat_id in chat_ids:
                        try:
                            await send_cwl_start(bot, chat_id, war, group, current_round)
                        except Exception as e:
                            logger.warning(f"cwl_watcher: ошибка отправки в {chat_id}: {e}")

            # Round ended
            elif current_state == "warEnded" and prev_state == "inWar":
                war, _, _ = await get_cwl_clan_war(coc.WarRound.previous_war)
                if war:
                    for chat_id in chat_ids:
                        try:
                            await send_cwl_end(bot, chat_id, war, prev_round)
                        except Exception as e:
                            logger.warning(f"cwl_watcher: ошибка отправки в {chat_id}: {e}")

            if current_state != prev_state or current_round != prev_round:
                storage.save_cwl_state(current_state, current_round)
                prev_state = current_state
                prev_round = current_round

        except coc.NotFound:
            pass  # Clan not in CWL this season
        except asyncio.CancelledError:
            break
        except Exception as e:
            logger.warning(f"cwl_state_monitor: {e}")


async def cwl_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    msg = await update.message.reply_text("⏳ Загружаю данные Лиги войн...")
    try:
        text, _ = await build_cwl_message()
        await msg.edit_text(text, parse_mode="HTML", reply_markup=KV_BUTTONS)
    except Exception as e:
        logger.error(f"Ошибка /cwl: {e}")
        await msg.edit_text("❌ Не удалось загрузить данные ЛВК. Попробуй позже.")


async def testcwlstart_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not _is_feolar(update):
        await update.message.reply_text("❌ Нет доступа.")
        return
    try:
        war, group, round_num = await get_cwl_clan_war()
        if war is None:
            await update.message.reply_text("⚠️ Клан не в ЛВК или нет активного раунда.")
            return
        await send_cwl_start(context.bot, update.effective_chat.id, war, group, round_num)
    except Exception as e:
        await update.message.reply_text(f"❌ Ошибка: {e}")


async def testcwlend_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not _is_feolar(update):
        await update.message.reply_text("❌ Нет доступа.")
        return
    try:
        war, group, round_num = await get_cwl_clan_war()
        if war is None:
            await update.message.reply_text("⚠️ Клан не в ЛВК или нет активного раунда.")
            return
        await send_cwl_end(context.bot, update.effective_chat.id, war, round_num)
    except Exception as e:
        await update.message.reply_text(f"❌ Ошибка: {e}")


CARD_BACKGROUNDS = [
    "card_background.png",
    "card_bg_2.png",
    "card_bg_3.png",
    "card_bg_4.png",
]

async def card_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    msg = await update.message.reply_text("🎨 Генерирую карточку клана, подождите...")
    try:
        clan = await coc_client.get_clan(CLAN_TAG)
        raids = []
        try:
            async for r in await coc_client.get_raid_log(CLAN_TAG, limit=4):
                raids.append(r)
        except Exception:
            pass
        available = [p for p in CARD_BACKGROUNDS if os.path.exists(p)]
        bg_path = __import__("random").choice(available) if available else None
        buf = await card_builder.build_card(clan, raids=raids, background_path=bg_path)
        await update.message.reply_photo(
            photo=buf,
            caption=(
                f"🏰 <b>{clan.name}</b>  ·  Уровень {clan.level}\n"
                f"👥 {clan.member_count} участников  ·  "
                f"⚔️ {clan.war_wins}П / {clan.war_losses}П"
            ),
            parse_mode="HTML",
        )
        await msg.delete()
    except Exception as e:
        import traceback
        traceback.print_exc()
        await msg.edit_text(f"❌ Ошибка генерации карточки: {e}")


async def addchat_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not _is_feolar(update):
        await update.message.reply_text("⛔ Только для администратора.")
        return
    chat_id = update.effective_chat.id
    chat_type = update.effective_chat.type
    chat_title = update.effective_chat.title or "личка"
    added = storage.add_notify_chat(chat_id)
    if added:
        await update.message.reply_text(
            f"✅ Чат добавлен в рассылку!\n"
            f"<b>{chat_title}</b> (ID: <code>{chat_id}</code>, тип: {chat_type})\n\n"
            "Теперь уведомления о КВ и ЛВК будут приходить сюда.",
            parse_mode="HTML",
        )
    else:
        await update.message.reply_text(
            f"ℹ️ Этот чат уже в списке рассылки.\n"
            f"ID: <code>{chat_id}</code>",
            parse_mode="HTML",
        )


async def removechat_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not _is_feolar(update):
        await update.message.reply_text("⛔ Только для администратора.")
        return
    chat_id = update.effective_chat.id
    chat_title = update.effective_chat.title or "личка"
    removed = storage.remove_notify_chat(chat_id)
    if removed:
        await update.message.reply_text(
            f"✅ Чат удалён из рассылки.\n"
            f"<b>{chat_title}</b> (ID: <code>{chat_id}</code>)",
            parse_mode="HTML",
        )
    else:
        await update.message.reply_text(
            f"ℹ️ Этот чат не был в списке рассылки.\n"
            f"ID: <code>{chat_id}</code>",
            parse_mode="HTML",
        )


async def listchats_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not _is_feolar(update):
        await update.message.reply_text("⛔ Только для администратора.")
        return
    chats = storage.get_notify_chats()
    if not chats:
        await update.message.reply_text("📭 Список чатов для рассылки пуст.")
        return
    lines = [f"📬 <b>Чаты для рассылки ({len(chats)}):</b>"]
    for i, cid in enumerate(chats, 1):
        lines.append(f"  {i}. <code>{cid}</code>")
    lines.append("\nℹ️ /addchat — добавить текущий чат\n/removechat — убрать текущий чат")
    await update.message.reply_text("\n".join(lines), parse_mode="HTML")


async def post_init(application):
    await coc_client.login(COC_EMAIL, COC_PASSWORD)
    logger.info("CoC клиент авторизован")

    asyncio.create_task(war_auto_broadcast(application.bot))
    asyncio.create_task(war_state_monitor(application.bot))
    asyncio.create_task(cwl_state_monitor(application.bot))
    logger.info("Авто-рассылка войны и ЛВК запущена")

    # Register bot commands (shown in Telegram command menu)
    await application.bot.set_my_commands([
        BotCommand("start",    "🏰 Главное меню"),
        BotCommand("team",     "📋 Список участников клана"),
        BotCommand("kv",       "⚔️ Атаки в клановой войне"),
        BotCommand("cwl",      "🏆 Статус Лиги войн клана"),
        BotCommand("statistic","📊 Статистика клана (Excel)"),
        BotCommand("card",     "🎨 Карточка клана"),
        BotCommand("register", "🔗 Привязать свой аккаунт CoC"),
        BotCommand("help",     "❓ Помощь по командам"),
        BotCommand("link",       "🛡 [Адм] Привязать игрока к Telegram"),
        BotCommand("unlink",     "🛡 [Адм] Убрать привязку игрока"),
        BotCommand("links",      "🛡 [Адм] Список всех привязок"),
        BotCommand("addchat",    "🛡 [Адм] Добавить чат в рассылку"),
        BotCommand("removechat", "🛡 [Адм] Убрать чат из рассылки"),
        BotCommand("listchats",  "🛡 [Адм] Список чатов рассылки"),
    ])
    await application.bot.set_chat_menu_button(menu_button=MenuButtonCommands())
    logger.info("Команды бота зарегистрированы")


async def post_shutdown(application):
    await coc_client.close()


async def conflict_error_handler(update, context):
    from telegram.error import Conflict
    if isinstance(context.error, Conflict):
        logger.warning("Конфликт: другой экземпляр бота работает. Жду освобождения...")
    else:
        logger.error(f"Ошибка: {context.error}")


class _HealthHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        self.send_response(200)
        self.end_headers()
        self.wfile.write(b"OK")

    def log_message(self, format, *args):
        pass


def _start_health_server():
    port = int(os.environ.get("PORT", 8080))
    server = HTTPServer(("0.0.0.0", port), _HealthHandler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    logger.info(f"Health check server listening on port {port}")


def main():
    _start_health_server()
    app = (
        ApplicationBuilder()
        .token(TOKEN)
        .post_init(post_init)
        .post_shutdown(post_shutdown)
        .build()
    )

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", help_command))
    app.add_handler(CommandHandler("team", team_command))
    app.add_handler(CommandHandler("register", register_command))
    app.add_handler(CommandHandler("online", online_command))
    app.add_handler(CommandHandler("kv", kv_command))
    app.add_handler(CommandHandler("link", link_command))
    app.add_handler(CommandHandler("unlink", unlink_command))
    app.add_handler(CommandHandler("links", links_command))
    app.add_handler(CommandHandler("teststart", teststart_command))
    app.add_handler(CommandHandler("testend", testend_command))
    app.add_handler(CommandHandler("cwl", cwl_command))
    app.add_handler(CommandHandler("statistic", statistic_command))
    app.add_handler(CommandHandler("testcwlstart", testcwlstart_command))
    app.add_handler(CommandHandler("testcwlend", testcwlend_command))
    app.add_handler(CommandHandler("card", card_command))
    app.add_handler(CommandHandler("addchat", addchat_command))
    app.add_handler(CommandHandler("removechat", removechat_command))
    app.add_handler(CommandHandler("listchats", listchats_command))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, echo))
    app.add_error_handler(conflict_error_handler)

    logger.info("Бот запущен...")
    app.run_polling()


if __name__ == "__main__":
    main()
